<?php
session_start();
?>
<html>
<head>
	<title>
		home
	</title>
	<link rel="stylesheet" href="project.css">
</head>
<body bgcolor="silver">
 <div class="menubar"style="background-image: url('image/bbms.jpg');">
	<ul>
		<img src="image/bbms5.webp" style="width: 200px;height: 80px;margin-right:10px ;padding-right: 20px;">
	     <li class="active" style="margin-right:1000px;"><a href="home.php">Home</a></li>		
    </ul>
</div>

<div class="about" style="background-color: green;width: 1535px;height:629px;font-size:35px;">
	<h2 style="text-align:center">Contact Us</h2>
	<p style="color: white;padding: 50px;">
		<div class="contact" style="margin-top:10 px;font-size:20px;margin-left: 500px;width: 500px;background-color: red;">
		<a href="https://vaibhavsrivastava1.blogspot.com/"style="text-decoration: none;color: white;"><h4 style="margin-left: 100px;">vaibhavsrivastava1.blogspot.com</h4></a>
	</div>
	<div class="contact" style="margin-top: 8px;margin-left: 600px;">facebook--
		<a href="https://www.facebook.com/IndianBloodDonors/"><img src="image/fb.png" style="width: 30px;"></a>
	</div>
	<div class="contact" style="margin-top: 8px;font-size:28px;margin-left: 600px;">Instagram--
		<a href="https://www.instagram.com/indiablooddonation/?hl=en"><img src="image/insta.png"style="width: 30px;"></a>
	</div>
	<div class="contact" style="margin-top: 8px;font-size:28px;margin-left: 600px;">Blogger--
		<a href="https://www.aimsindia.com/blog/be-a-blood-donor/"><img src="image/blog.png"style="width: 30px;"></a>
	</div>
	</div>
	</p>
</div>
<div class="foot" style="background-image: url('image/bbms.jpg');background-color:green;width: 1536px;display: inline-flex;margin-top: px;height:42px;">
	<div class="about" style="margin-top: 10px;font-size:18px;margin-left: 10px;">
   <a href="abo.php" style="text-decoration: none;color: white;">About us</a>
	</div>
	<div class="contact" style="margin-top: 10px;font-size:18px;margin-left: 10px;">
		<a href="Cont.php"style="text-decoration: none;color: white;">Contact us</a>
	</div>
	<div class="contact" style="margin-top: 10px;font-size:18px;margin-left: 500px;">
		<a href="https://vaibhavsrivastava1.blogspot.com/"style="text-decoration: none;color: white;">vaibhavsrivastava1.blogspot.com</a>
	</div>
	<div class="contact" style="margin-top: 8px;margin-left: 500px;">
		<a href="https://www.facebook.com/IndianBloodDonors/"><img src="image/fb.png" style="width: 30px;"></a>
	</div>
	<div class="contact" style="margin-top: 8px;font-size:18px;margin-left: 10px;">
		<a href="https://www.instagram.com/indiablooddonation/?hl=en"><img src="image/insta.png"style="width: 30px;"></a>
	</div>
	<div class="contact" style="margin-top: 8px;font-size:18px;margin-left: 10px;">
		<a href="https://www.aimsindia.com/blog/be-a-blood-donor/"><img src="image/blog.png"style="width: 30px;"></a>
	</div>
	</div>
</body>
</html>

